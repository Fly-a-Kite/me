# Final Freeze Manifest - 2026-05-22

Read `FINAL_GOAL.md` first. This manifest freezes the final experiment harness before
counted runs. It records a dirty workspace snapshot, not a clean release commit.

## Freeze Identity

- Freeze id: `20260522T0034+0800`
- Created at: `2026-05-22T00:34:19+08:00`
- Git branch: `main`
- Git HEAD: `7a76c9c77d7dcf452f6b85b9ebdd4f393195e8c2`
- Dirty workspace: `true`
- Tracked diff SHA-256: `8382da17144d49de7285d9a8e10a7e528abb509e6f818a9a5cc5a287a4eb70eb`
- JSON manifest: `reports/final-freeze-manifest-20260522T0034+0800.json`

## Dirty Tree Policy

Counted runs use this frozen workspace snapshot: git HEAD plus the dirty tracked patch and untracked critical files listed in this manifest. Any change to generator, oracle, normalizer, guidance, reducer, triage, scheduler, targets, backends, or final planning code requires a new freeze manifest; runs from different freezes must not be merged as one final run.

After this freeze, do not change generator, oracle, normalizer, guidance, reducer,
triage, scheduler, backend adapters, target registry, or final planning code for counted
runs. If such a change is necessary, create a new freeze manifest and keep result tables
separate by freeze id.

## Execution Policy

- `--track all` is review-only; direct `--track all --execute` is rejected.
- Live discovery: run from `/tmp/datadiff-final-live-latest-yULeNP`.
- Seeded sensitivity: run from `/tmp/datadiff-final-live-latest-yULeNP`; do not count seeded faults as real bugs.
- Historical replay: run from `/tmp/datadiff-duckdb-22656-vuln-AaPutg` for DuckDB 1.5.2 vulnerable replays.

## Environments

| environment | python | pandas | polars | duckdb | pyarrow | datafusion | pytest |
|---|---|---|---|---|---|---|---|
| dev | 3.12.3 | 3.0.3 | 1.40.1 | 1.5.2 | 24.0.0 | 53.0.0 | 9.0.3 |
| latest live | 3.12.3 | 3.0.3 | 1.40.1 | 1.5.3 | 24.0.0 | 53.0.0 | 9.0.3 |
| historical vulnerable | 3.12.3 | 3.0.3 | n/a | 1.5.2 | n/a | n/a | n/a |
| historical fixed | 3.12.3 | 3.0.3 | n/a | 1.5.3 | n/a | n/a | n/a |

Pip freeze files:

- `reports/pip-freeze-dev-freeze-20260522.txt` sha256 `94d9b65511fd340742a1264f6ac9a2b16c0685cafe260a26d0ae6cb75c01c10d`
- `reports/pip-freeze-final-live-freeze-20260522.txt` sha256 `1618e442ecbb5df42c44ec15ada69375ef6b1556911461edb914b26efe3a1084`
- `reports/pip-freeze-historical-vuln-freeze-20260522.txt` sha256 `0a9df8f400c5542f66e7431dbacb2413bc64255a643aca03a5f4c3f27dfcd044`
- `reports/pip-freeze-historical-fixed-freeze-20260522.txt` sha256 `23775d755543382305de2ef0d37d5e08d6d9b62890426c59b873bce6f0509e4a`

## Tests

- Dev venv: `286 passed in 3.05s`, log `reports/pytest-dev-freeze-20260522.txt`, sha256 `5d172184581d314cc3296f62e8cdab8eb004dfac22e0b8b6f94bb6052a6636b7`
- Latest live venv: `286 passed in 3.08s`, log `reports/pytest-final-live-freeze-20260522.txt`, sha256 `c42bb57a086789bc8970492b52ad43ca8899742c729e61f4c939fd0e629d96d3`
- Mixed all-track execution guard: `--track all --execute` exits with code 2.

## Frozen Plans

- `all_review_only`: `reports/final-experiment-plan-20260521T163114-1779381074199056594.json` sha256 `d18f7cd1cfb4e3129d6e4e2c0c6e4efd4b16807439d3092b9b1ad4f33da2d681`
- `live_execute_from_latest_venv`: `reports/final-experiment-plan-20260521T163131-1779381091663718127.json` sha256 `a80f5f3adb06b23ea9f060059468d26afa58832626ceea1aba15fcbfb630bf29`
- `seeded_execute_from_latest_venv`: `reports/final-experiment-plan-20260521T163131-1779381091970663771.json` sha256 `5c2244818937bd3033956916f3e22ad95c03d94a8edcdd5863dd9efe8825a15c`
- `historical_execute_from_vulnerable_venv`: `reports/final-experiment-plan-20260521T163131-1779381091972219226.json` sha256 `0022a1b311728af1313cbb84b64334f9ed81f611bc0f1fb838bf6ae931c61d01`

## Historical Registry At Freeze

- Counted confirmed historical replays: `duckdb-22075`, `duckdb-22656`
- Pending/case-study entries: `duckdb-3015`, `datafusion-22190`

## Git Status Snapshot

```text
   M README.md
   M REPRODUCE.md
   M bugs/bug_9b4d1fa7aac3b391/upstream_issue.md
   M reports/datafusion-upstream-issue-bundle.tar.gz
   M reports/datafusion-upstream-issue-bundle.tar.gz.sha256
   M reports/datafusion-upstream-issue-checklist.md
   M reports/icse-methodology-roadmap.md
   M reports/ubuntu-datafusion-artifact-bundle.tar.gz
   M reports/ubuntu-datafusion-artifact-bundle.tar.gz.sha256
   M reports/ubuntu-datafusion-artifact-manifest.json
   M reports/ubuntu-datafusion-confirmation.md
   M scripts/build_ubuntu_artifact_bundle.py
   M scripts/build_upstream_issue_bundle.py
   M src/datadiff/backends/__init__.py
   M src/datadiff/backends/datafusion_backend.py
   M src/datadiff/backends/duckdb_backend.py
   M src/datadiff/backends/pandas_backend.py
   M src/datadiff/backends/polars_backend.py
   M src/datadiff/backends/pyarrow_backend.py
   M src/datadiff/backends/sqlite_backend.py
   M src/datadiff/classification_oracle.py
   M src/datadiff/cli.py
   M src/datadiff/config.py
   M src/datadiff/datagen.py
   M src/datadiff/dsl.py
   M src/datadiff/experiment_analysis.py
   M src/datadiff/feedback.py
   M src/datadiff/guidance.py
   M src/datadiff/metamorphic.py
   M src/datadiff/mutator.py
   M src/datadiff/oracle.py
   M src/datadiff/pattern_analysis.py
   M src/datadiff/preflight.py
   M src/datadiff/reducer.py
   M src/datadiff/reporter.py
   M src/datadiff/runner.py
   M src/datadiff/targets.py
   M src/datadiff/triage.py
   M tests/test_artifact_bundle.py
   M tests/test_classification_oracle.py
   M tests/test_cli.py
   M tests/test_datagen.py
   M tests/test_experiment_analysis.py
   M tests/test_feedback.py
   M tests/test_guidance.py
   M tests/test_methodology_contracts.py
   M tests/test_mutator.py
   M tests/test_preflight.py
   M tests/test_reducer.py
   M tests/test_reporter.py
   M tests/test_runner.py
   M tests/test_targets.py
   M tests/test_upstream_issue_bundle.py
  ?? FINAL_GOAL.md
  ?? experiments/
  ?? scripts/run_final_experiments.py
  ?? src/datadiff/fixture_replay.py
  ?? src/datadiff/fixtures.py
  ?? src/datadiff/historical.py
  ?? src/datadiff/operation_combo.py
  ?? src/datadiff/reward.py
  ?? src/datadiff/run_journal.py
  ?? src/datadiff/scheduler.py
  ?? tests/test_final_experiment_plan.py
  ?? tests/test_fixtures.py
  ?? tests/test_operation_combo.py
  ?? tests/test_run_journal.py
  ?? tests/test_scheduler.py
```

## Critical File Hashes

The JSON manifest contains SHA-256 hashes for 82 critical source,
test, script, and protocol files under `critical_file_hashes`.
