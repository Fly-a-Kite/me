# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T193946.json`
- Runs: 36
- Presets: bughunt_no_groupby, bughunt_no_groupby_guided, bughunt_no_groupby_metamorphic
- Seeds: 101, 1101, 2101
- Backends: duckdb, pandas, polars, polars_lazy, pyarrow, sqlite
- Target suite: core,core_lazy,core_arrow,arrow_cross
- Target suites: core, core_lazy, core_arrow, arrow_cross
- Target families: dataframe:3; embedded_sql:2; arrow:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T193946-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core | bughunt_no_groupby | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 17.27 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | bughunt_no_groupby | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 17.07 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | bughunt_no_groupby | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 17.08 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | bughunt_no_groupby_guided | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 76.4% | 14.71 | 1.39 | 1.09 | 0.81 | 5.87 | 0.0% | none | none |
| core | bughunt_no_groupby_guided | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 71.2% | 14.82 | 1.41 | 1.10 | 0.79 | 5.90 | 0.0% | none | none |
| core | bughunt_no_groupby_guided | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 77.2% | 14.87 | 1.39 | 1.09 | 0.81 | 5.90 | 0.0% | none | none |
| core | bughunt_no_groupby_metamorphic | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 2.14 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | bughunt_no_groupby_metamorphic | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 2.12 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | bughunt_no_groupby_metamorphic | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 2.12 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 15.95 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 15.68 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 15.72 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_guided | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 76.4% | 14.19 | 1.39 | 1.09 | 0.81 | 5.87 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_guided | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 71.2% | 13.92 | 1.41 | 1.10 | 0.79 | 5.90 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_guided | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 77.2% | 14.31 | 1.39 | 1.09 | 0.81 | 5.90 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_metamorphic | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 1.98 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_metamorphic | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 1.97 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | bughunt_no_groupby_metamorphic | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 1.96 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 14.91 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 14.68 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 14.57 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_guided | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 76.4% | 13.44 | 1.39 | 1.09 | 0.81 | 5.87 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_guided | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 71.2% | 13.44 | 1.41 | 1.10 | 0.79 | 5.90 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_guided | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 77.2% | 13.76 | 1.39 | 1.09 | 0.81 | 5.90 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_metamorphic | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 1.87 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_metamorphic | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 1.85 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | bughunt_no_groupby_metamorphic | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 1.84 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 19.44 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 19.56 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 19.57 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_guided | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 76.4% | 15.94 | 1.39 | 1.09 | 0.81 | 5.87 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_guided | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 71.2% | 15.99 | 1.41 | 1.10 | 0.79 | 5.90 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_guided | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 77.2% | 16.15 | 1.39 | 1.09 | 0.81 | 5.90 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_metamorphic | 101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.9% | 2.33 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_metamorphic | 1101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 85.8% | 2.31 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | bughunt_no_groupby_metamorphic | 2101 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 86.8% | 2.32 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| arrow_cross | bughunt_no_groupby | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 19.52 | 0.00 | 0.00 |
| arrow_cross | bughunt_no_groupby_guided | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 74.9% | 16.03 | 1.40 | 1.09 |
| arrow_cross | bughunt_no_groupby_metamorphic | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 2.32 | 0.00 | 0.00 |
| core | bughunt_no_groupby | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 17.14 | 0.00 | 0.00 |
| core | bughunt_no_groupby_guided | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 74.9% | 14.80 | 1.40 | 1.09 |
| core | bughunt_no_groupby_metamorphic | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 2.13 | 0.00 | 0.00 |
| core_arrow | bughunt_no_groupby | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 14.72 | 0.00 | 0.00 |
| core_arrow | bughunt_no_groupby_guided | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 74.9% | 13.55 | 1.40 | 1.09 |
| core_arrow | bughunt_no_groupby_metamorphic | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 1.85 | 0.00 | 0.00 |
| core_lazy | bughunt_no_groupby | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 15.79 | 0.00 | 0.00 |
| core_lazy | bughunt_no_groupby_guided | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 74.9% | 14.14 | 1.40 | 1.09 |
| core_lazy | bughunt_no_groupby_metamorphic | 3 | 3000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 86.2% | 1.97 | 0.00 | 0.00 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| arrow_cross | bughunt_no_groupby | 0 | none |
| arrow_cross | bughunt_no_groupby_guided | 0 | none |
| arrow_cross | bughunt_no_groupby_metamorphic | 0 | none |
| core | bughunt_no_groupby | 0 | none |
| core | bughunt_no_groupby_guided | 0 | none |
| core | bughunt_no_groupby_metamorphic | 0 | none |
| core_arrow | bughunt_no_groupby | 0 | none |
| core_arrow | bughunt_no_groupby_guided | 0 | none |
| core_arrow | bughunt_no_groupby_metamorphic | 0 | none |
| core_lazy | bughunt_no_groupby | 0 | none |
| core_lazy | bughunt_no_groupby_guided | 0 | none |
| core_lazy | bughunt_no_groupby_metamorphic | 0 | none |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
