# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T190631.json`
- Runs: 180
- Presets: baseline, guided, no_feedback, no_type_aware, no_normalizer, metamorphic
- Seeds: 1, 1001, 2001, 3001, 4001
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, pyarrow, sqlite
- Target suite: core,core_lazy,core_datafusion,core_arrow,datafusion_cross,arrow_cross
- Target suites: core, core_lazy, core_datafusion, core_arrow, datafusion_cross, arrow_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1; arrow:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T190631-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 25.69 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | baseline | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 25.50 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 24.94 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 25.48 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 25.12 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 19.77 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| core | guided | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 78.0% | 19.77 | 1.38 | 1.06 | 0.83 | 2.43 | 2.9% | none | none |
| core | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 19.82 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| core | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 20.00 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| core | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 19.74 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| core | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 25.46 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | no_feedback | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.4% | 25.41 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 24.94 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 25.35 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 24.90 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | no_type_aware | 1 | 500 | 3 | 1 | 0.2% | 204 | 2 | 0 | 85.2% | 27.84 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:1; filter_predicate:1; ordering_or_limit:1 | expected_semantic_divergence:2; candidate_implementation_bug:1 |
| core | no_type_aware | 1001 | 500 | 7 | 1 | 0.2% | 6 | 6 | 0 | 80.0% | 27.92 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:4; groupby_aggregation:3 | expected_semantic_divergence:6; candidate_implementation_bug:1 |
| core | no_type_aware | 2001 | 500 | 6 | 2 | 0.4% | 16 | 4 | 0 | 84.0% | 28.28 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:2; filter_predicate:2; ordering_or_limit:1; groupby_aggregation:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| core | no_type_aware | 3001 | 500 | 6 | 4 | 0.8% | 25 | 2 | 0 | 81.6% | 28.52 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:3; filter_predicate:1; groupby_aggregation:1; ordering_or_limit:1 | candidate_implementation_bug:4; expected_semantic_divergence:2 |
| core | no_type_aware | 4001 | 500 | 7 | 0 | 0.0% |  | 7 | 0 | 80.4% | 28.55 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; filter_predicate:2; groupby_aggregation:2 | expected_semantic_divergence:7 |
| core | no_normalizer | 1 | 500 | 172 | 0 | 0.0% |  | 0 | 172 | 85.8% | 25.47 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:143; join_semantics:20; ordering_or_limit:3; filter_predicate:3; arithmetic_expression:2 | normalizer_false_positive:172 |
| core | no_normalizer | 1001 | 500 | 144 | 0 | 0.0% |  | 0 | 144 | 85.6% | 25.31 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:112; join_semantics:15; filter_predicate:9; ordering_or_limit:4; arithmetic_expression:4 | normalizer_false_positive:144 |
| core | no_normalizer | 2001 | 500 | 117 | 0 | 0.0% |  | 0 | 117 | 82.0% | 25.24 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:82; join_semantics:27; filter_predicate:4; ordering_or_limit:3; type_cast:1 | normalizer_false_positive:117 |
| core | no_normalizer | 3001 | 500 | 123 | 0 | 0.0% |  | 0 | 123 | 84.0% | 25.77 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:101; join_semantics:12; ordering_or_limit:5; filter_predicate:2; string_expression:1 | normalizer_false_positive:123 |
| core | no_normalizer | 4001 | 500 | 131 | 0 | 0.0% |  | 0 | 131 | 85.0% | 25.50 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:100; join_semantics:21; ordering_or_limit:7; string_expression:2; type_cast:1 | normalizer_false_positive:131 |
| core | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.28 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | metamorphic | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 5.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 5.26 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 5.25 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 23.99 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | baseline | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 24.14 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 23.74 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 24.28 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 23.91 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 18.72 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| core_lazy | guided | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 78.0% | 18.77 | 1.38 | 1.06 | 0.83 | 2.43 | 2.9% | none | none |
| core_lazy | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 18.91 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| core_lazy | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 19.34 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| core_lazy | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 18.83 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| core_lazy | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 23.94 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | no_feedback | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.4% | 23.65 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 23.79 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 24.24 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 23.47 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | no_type_aware | 1 | 500 | 4 | 2 | 0.4% | 93 | 2 | 0 | 85.0% | 25.88 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:2; filter_predicate:1; ordering_or_limit:1 | candidate_implementation_bug:2; expected_semantic_divergence:2 |
| core_lazy | no_type_aware | 1001 | 500 | 5 | 1 | 0.2% | 6 | 4 | 0 | 80.2% | 26.52 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:3; groupby_aggregation:2 | expected_semantic_divergence:4; candidate_implementation_bug:1 |
| core_lazy | no_type_aware | 2001 | 500 | 6 | 2 | 0.4% | 16 | 4 | 0 | 84.0% | 26.34 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:2; filter_predicate:2; ordering_or_limit:1; groupby_aggregation:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| core_lazy | no_type_aware | 3001 | 500 | 6 | 4 | 0.8% | 25 | 2 | 0 | 81.4% | 26.48 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:3; filter_predicate:1; groupby_aggregation:1; ordering_or_limit:1 | candidate_implementation_bug:4; expected_semantic_divergence:2 |
| core_lazy | no_type_aware | 4001 | 500 | 8 | 1 | 0.2% | 270 | 7 | 0 | 80.6% | 26.57 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; groupby_aggregation:3; filter_predicate:2 | expected_semantic_divergence:7; candidate_implementation_bug:1 |
| core_lazy | no_normalizer | 1 | 500 | 176 | 0 | 0.0% |  | 0 | 176 | 86.8% | 24.19 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:140; join_semantics:23; arithmetic_expression:7; filter_predicate:3; ordering_or_limit:2 | normalizer_false_positive:176 |
| core_lazy | no_normalizer | 1001 | 500 | 144 | 0 | 0.0% |  | 0 | 144 | 87.6% | 23.97 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:116; join_semantics:12; filter_predicate:9; arithmetic_expression:4; ordering_or_limit:3 | normalizer_false_positive:144 |
| core_lazy | no_normalizer | 2001 | 500 | 122 | 0 | 0.0% |  | 0 | 122 | 84.2% | 23.73 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:87; join_semantics:27; filter_predicate:4; ordering_or_limit:3; type_cast:1 | normalizer_false_positive:122 |
| core_lazy | no_normalizer | 3001 | 500 | 127 | 0 | 0.0% |  | 0 | 127 | 86.2% | 24.11 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:103; join_semantics:13; ordering_or_limit:5; filter_predicate:3; string_expression:1 | normalizer_false_positive:127 |
| core_lazy | no_normalizer | 4001 | 500 | 136 | 0 | 0.0% |  | 0 | 136 | 86.4% | 23.77 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:105; join_semantics:21; ordering_or_limit:7; string_expression:2; type_cast:1 | normalizer_false_positive:136 |
| core_lazy | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.99 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | metamorphic | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 5.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 4.91 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_lazy | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 4.97 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 20.38 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | baseline | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 83.0% | 20.15 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 20.09 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 20.79 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 20.32 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 15.84 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| core_datafusion | guided | 1001 | 500 | 1 | 1 | 0.2% | 434 | 0 | 0 | 77.4% | 16.13 | 1.38 | 1.06 | 0.83 | 2.42 | 2.9% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 15.79 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| core_datafusion | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 16.36 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| core_datafusion | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 15.90 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| core_datafusion | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 20.41 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | no_feedback | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 99.4% | 20.35 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 20.13 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 20.65 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 20.17 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | no_type_aware | 1 | 500 | 6 | 2 | 0.4% | 93 | 4 | 0 | 85.0% | 22.42 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; groupby_aggregation:2; filter_predicate:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| core_datafusion | no_type_aware | 1001 | 500 | 8 | 2 | 0.4% | 6 | 6 | 0 | 80.2% | 22.79 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:3; filter_predicate:3; ordering_or_limit:1; grouped_topk_null_sort_key:1 | expected_semantic_divergence:6; candidate_implementation_bug:2 |
| core_datafusion | no_type_aware | 2001 | 500 | 8 | 2 | 0.4% | 16 | 6 | 0 | 84.0% | 22.76 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; arithmetic_expression:2; filter_predicate:2; groupby_aggregation:1 | expected_semantic_divergence:6; candidate_implementation_bug:2 |
| core_datafusion | no_type_aware | 3001 | 500 | 8 | 4 | 0.8% | 25 | 4 | 0 | 81.4% | 23.02 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; arithmetic_expression:3; filter_predicate:1; groupby_aggregation:1 | expected_semantic_divergence:4; candidate_implementation_bug:4 |
| core_datafusion | no_type_aware | 4001 | 500 | 10 | 1 | 0.2% | 270 | 9 | 0 | 80.4% | 22.93 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:5; groupby_aggregation:3; filter_predicate:2 | expected_semantic_divergence:9; candidate_implementation_bug:1 |
| core_datafusion | no_normalizer | 1 | 500 | 177 | 0 | 0.0% |  | 0 | 177 | 86.8% | 20.89 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:141; join_semantics:21; arithmetic_expression:8; ordering_or_limit:3; filter_predicate:3 | normalizer_false_positive:177 |
| core_datafusion | no_normalizer | 1001 | 500 | 148 | 0 | 0.0% |  | 0 | 147 | 87.6% | 20.26 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:118; join_semantics:13; filter_predicate:9; arithmetic_expression:4; ordering_or_limit:3 | normalizer_false_positive:147; needs_manual_confirmation:1 |
| core_datafusion | no_normalizer | 2001 | 500 | 122 | 0 | 0.0% |  | 0 | 122 | 84.0% | 20.23 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:86; join_semantics:28; filter_predicate:4; ordering_or_limit:3; type_cast:1 | normalizer_false_positive:122 |
| core_datafusion | no_normalizer | 3001 | 500 | 125 | 0 | 0.0% |  | 0 | 125 | 86.0% | 20.61 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:104; join_semantics:11; ordering_or_limit:5; filter_predicate:2; string_expression:1 | normalizer_false_positive:125 |
| core_datafusion | no_normalizer | 4001 | 500 | 136 | 0 | 0.0% |  | 0 | 136 | 86.0% | 20.20 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:105; join_semantics:21; ordering_or_limit:5; string_expression:3; type_cast:1 | normalizer_false_positive:136 |
| core_datafusion | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.19 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | metamorphic | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 83.0% | 4.17 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 4.15 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.22 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_datafusion | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 4.19 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 22.61 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | baseline | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 22.96 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 21.95 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 22.86 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 22.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 17.94 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| core_arrow | guided | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 78.0% | 18.14 | 1.38 | 1.06 | 0.83 | 2.43 | 2.9% | none | none |
| core_arrow | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 18.26 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| core_arrow | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 18.39 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| core_arrow | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 18.04 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| core_arrow | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 22.81 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | no_feedback | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.4% | 22.59 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 22.41 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 22.85 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 22.18 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | no_type_aware | 1 | 500 | 4 | 2 | 0.4% | 93 | 2 | 0 | 85.0% | 24.86 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:2; filter_predicate:1; ordering_or_limit:1 | candidate_implementation_bug:2; expected_semantic_divergence:2 |
| core_arrow | no_type_aware | 1001 | 500 | 5 | 1 | 0.2% | 6 | 4 | 0 | 80.2% | 25.29 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:3; groupby_aggregation:2 | expected_semantic_divergence:4; candidate_implementation_bug:1 |
| core_arrow | no_type_aware | 2001 | 500 | 6 | 2 | 0.4% | 16 | 4 | 0 | 84.0% | 24.99 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:2; filter_predicate:2; ordering_or_limit:1; groupby_aggregation:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| core_arrow | no_type_aware | 3001 | 500 | 6 | 4 | 0.8% | 25 | 2 | 0 | 81.4% | 25.23 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | arithmetic_expression:3; filter_predicate:1; groupby_aggregation:1; ordering_or_limit:1 | candidate_implementation_bug:4; expected_semantic_divergence:2 |
| core_arrow | no_type_aware | 4001 | 500 | 8 | 1 | 0.2% | 270 | 7 | 0 | 80.4% | 25.25 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; groupby_aggregation:3; filter_predicate:2 | expected_semantic_divergence:7; candidate_implementation_bug:1 |
| core_arrow | no_normalizer | 1 | 500 | 175 | 0 | 0.0% |  | 0 | 175 | 86.4% | 23.10 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:135; join_semantics:24; arithmetic_expression:7; ordering_or_limit:4; filter_predicate:4 | normalizer_false_positive:175 |
| core_arrow | no_normalizer | 1001 | 500 | 149 | 0 | 0.0% |  | 0 | 149 | 87.2% | 23.06 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:120; join_semantics:13; filter_predicate:9; arithmetic_expression:4; ordering_or_limit:3 | normalizer_false_positive:149 |
| core_arrow | no_normalizer | 2001 | 500 | 118 | 0 | 0.0% |  | 0 | 118 | 83.6% | 22.55 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:84; join_semantics:27; filter_predicate:4; ordering_or_limit:2; type_cast:1 | normalizer_false_positive:118 |
| core_arrow | no_normalizer | 3001 | 500 | 123 | 0 | 0.0% |  | 0 | 123 | 85.2% | 22.84 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:102; join_semantics:11; ordering_or_limit:5; filter_predicate:2; string_expression:1 | normalizer_false_positive:123 |
| core_arrow | no_normalizer | 4001 | 500 | 140 | 0 | 0.0% |  | 0 | 140 | 86.4% | 22.41 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:107; join_semantics:24; ordering_or_limit:7; string_expression:1; type_cast:1 | normalizer_false_positive:140 |
| core_arrow | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.73 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | metamorphic | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 4.74 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 4.64 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.78 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| core_arrow | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 4.71 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 23.95 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | baseline | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 83.0% | 24.17 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 23.95 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 24.71 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 24.46 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 18.29 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| datafusion_cross | guided | 1001 | 500 | 1 | 1 | 0.2% | 434 | 0 | 0 | 77.4% | 18.43 | 1.38 | 1.06 | 0.83 | 2.42 | 2.9% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 18.37 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| datafusion_cross | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 18.84 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| datafusion_cross | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 18.36 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| datafusion_cross | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 24.67 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | no_feedback | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 99.4% | 24.36 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 24.40 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 24.72 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 23.79 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | no_type_aware | 1 | 500 | 6 | 2 | 0.4% | 93 | 4 | 0 | 85.0% | 26.77 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; groupby_aggregation:2; filter_predicate:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| datafusion_cross | no_type_aware | 1001 | 500 | 8 | 2 | 0.4% | 6 | 6 | 0 | 80.0% | 27.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:4; groupby_aggregation:2; ordering_or_limit:1; grouped_topk_null_sort_key:1 | expected_semantic_divergence:6; candidate_implementation_bug:2 |
| datafusion_cross | no_type_aware | 2001 | 500 | 7 | 1 | 0.2% | 16 | 6 | 0 | 84.0% | 26.82 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; filter_predicate:2; arithmetic_expression:1; groupby_aggregation:1 | expected_semantic_divergence:6; candidate_implementation_bug:1 |
| datafusion_cross | no_type_aware | 3001 | 500 | 6 | 2 | 0.4% | 204 | 4 | 0 | 81.4% | 27.25 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:3; filter_predicate:1; groupby_aggregation:1; arithmetic_expression:1 | expected_semantic_divergence:4; candidate_implementation_bug:2 |
| datafusion_cross | no_type_aware | 4001 | 500 | 10 | 1 | 0.2% | 270 | 9 | 0 | 80.4% | 27.42 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | ordering_or_limit:5; groupby_aggregation:3; filter_predicate:2 | expected_semantic_divergence:9; candidate_implementation_bug:1 |
| datafusion_cross | no_normalizer | 1 | 500 | 174 | 0 | 0.0% |  | 0 | 174 | 86.8% | 24.30 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:143; join_semantics:19; arithmetic_expression:5; filter_predicate:4; ordering_or_limit:2 | normalizer_false_positive:174 |
| datafusion_cross | no_normalizer | 1001 | 500 | 147 | 1 | 0.2% | 481 | 0 | 145 | 88.2% | 24.12 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:117; join_semantics:12; filter_predicate:9; arithmetic_expression:4; ordering_or_limit:3 | normalizer_false_positive:145; needs_manual_confirmation:1; candidate_implementation_bug:1 |
| datafusion_cross | no_normalizer | 2001 | 500 | 124 | 0 | 0.0% |  | 0 | 124 | 84.4% | 24.10 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:90; join_semantics:26; filter_predicate:4; ordering_or_limit:3; type_cast:1 | normalizer_false_positive:124 |
| datafusion_cross | no_normalizer | 3001 | 500 | 124 | 0 | 0.0% |  | 0 | 124 | 86.2% | 24.65 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:103; join_semantics:11; ordering_or_limit:6; filter_predicate:2; string_expression:1 | normalizer_false_positive:124 |
| datafusion_cross | no_normalizer | 4001 | 500 | 132 | 0 | 0.0% |  | 0 | 132 | 85.8% | 24.08 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:103; join_semantics:19; ordering_or_limit:5; string_expression:3; type_cast:1 | normalizer_false_positive:132 |
| datafusion_cross | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 4.97 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | metamorphic | 1001 | 500 | 1 | 1 | 0.2% | 474 | 0 | 0 | 83.0% | 4.98 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 4.97 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.04 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| datafusion_cross | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 4.96 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | baseline | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 27.73 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | baseline | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 27.87 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | baseline | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 27.66 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | baseline | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 28.01 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | baseline | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 27.43 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | guided | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 21.49 | 1.37 | 1.07 | 0.81 | 2.45 | 3.2% | none | none |
| arrow_cross | guided | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 78.0% | 21.49 | 1.38 | 1.06 | 0.83 | 2.43 | 2.9% | none | none |
| arrow_cross | guided | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.0% | 21.83 | 1.37 | 1.05 | 0.85 | 2.44 | 3.2% | none | none |
| arrow_cross | guided | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 77.6% | 22.30 | 1.37 | 1.04 | 0.83 | 2.36 | 3.8% | none | none |
| arrow_cross | guided | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 74.2% | 21.55 | 1.39 | 1.06 | 0.82 | 2.42 | 3.2% | none | none |
| arrow_cross | no_feedback | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.8% | 27.79 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | no_feedback | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.4% | 27.73 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | no_feedback | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 29.07 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | no_feedback | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 100.0% | 29.77 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | no_feedback | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 99.6% | 30.93 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | no_type_aware | 1 | 500 | 2 | 1 | 0.2% | 204 | 1 | 0 | 85.0% | 33.88 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:1; filter_predicate:1 | candidate_implementation_bug:1; expected_semantic_divergence:1 |
| arrow_cross | no_type_aware | 1001 | 500 | 5 | 1 | 0.2% | 6 | 4 | 0 | 80.2% | 35.64 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:3; groupby_aggregation:2 | expected_semantic_divergence:4; candidate_implementation_bug:1 |
| arrow_cross | no_type_aware | 2001 | 500 | 3 | 0 | 0.0% |  | 3 | 0 | 84.0% | 36.41 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:2; groupby_aggregation:1 | expected_semantic_divergence:3 |
| arrow_cross | no_type_aware | 3001 | 500 | 3 | 2 | 0.4% | 204 | 1 | 0 | 81.4% | 36.34 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | filter_predicate:1; groupby_aggregation:1; arithmetic_expression:1 | candidate_implementation_bug:2; expected_semantic_divergence:1 |
| arrow_cross | no_type_aware | 4001 | 500 | 6 | 1 | 0.2% | 270 | 5 | 0 | 80.4% | 36.85 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:3; filter_predicate:2; ordering_or_limit:1 | expected_semantic_divergence:5; candidate_implementation_bug:1 |
| arrow_cross | no_normalizer | 1 | 500 | 139 | 0 | 0.0% |  | 0 | 139 | 85.6% | 33.86 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:95; join_semantics:19; filter_predicate:16; ordering_or_limit:4; arithmetic_expression:4 | normalizer_false_positive:139 |
| arrow_cross | no_normalizer | 1001 | 500 | 133 | 0 | 0.0% |  | 0 | 133 | 86.2% | 33.16 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:103; join_semantics:12; filter_predicate:9; ordering_or_limit:4; arithmetic_expression:4 | normalizer_false_positive:133 |
| arrow_cross | no_normalizer | 2001 | 500 | 113 | 0 | 0.0% |  | 0 | 113 | 82.8% | 33.64 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:79; join_semantics:24; filter_predicate:5; ordering_or_limit:4; type_cast:1 | normalizer_false_positive:113 |
| arrow_cross | no_normalizer | 3001 | 500 | 115 | 0 | 0.0% |  | 0 | 115 | 84.2% | 34.94 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:93; join_semantics:12; ordering_or_limit:5; filter_predicate:2; string_expression:1 | normalizer_false_positive:115 |
| arrow_cross | no_normalizer | 4001 | 500 | 125 | 0 | 0.0% |  | 0 | 125 | 85.4% | 33.78 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | groupby_aggregation:97; join_semantics:19; ordering_or_limit:6; string_expression:2; type_cast:1 | normalizer_false_positive:125 |
| arrow_cross | metamorphic | 1 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.73 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | metamorphic | 1001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 5.72 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | metamorphic | 2001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 81.4% | 5.71 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | metamorphic | 3001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.2% | 5.78 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |
| arrow_cross | metamorphic | 4001 | 500 | 0 | 0 | 0.0% |  | 0 | 0 | 83.0% | 5.76 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0% | none | none |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| arrow_cross | baseline | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 27.74 | 0.00 | 0.00 |
| arrow_cross | guided | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 77.6% | 21.73 | 1.38 | 1.06 |
| arrow_cross | metamorphic | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 5.74 | 0.00 | 0.00 |
| arrow_cross | no_feedback | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 99.8% | 29.06 | 0.00 | 0.00 |
| arrow_cross | no_normalizer | 5 | 2500 | 625 | 0 | 0.0% | 0.00 |  | 0 | 625 | 84.8% | 33.88 | 0.00 | 0.00 |
| arrow_cross | no_type_aware | 5 | 2500 | 19 | 5 | 0.2% | 0.07 | 204 | 14 | 0 | 82.2% | 35.82 | 0.00 | 0.00 |
| core | baseline | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 25.35 | 0.00 | 0.00 |
| core | guided | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 77.6% | 19.82 | 1.38 | 1.06 |
| core | metamorphic | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 5.28 | 0.00 | 0.00 |
| core | no_feedback | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 99.8% | 25.21 | 0.00 | 0.00 |
| core | no_normalizer | 5 | 2500 | 687 | 0 | 0.0% | 0.00 |  | 0 | 687 | 84.5% | 25.46 | 0.00 | 0.00 |
| core | no_type_aware | 5 | 2500 | 29 | 8 | 0.3% | 0.09 | 20.5 | 21 | 0 | 82.2% | 28.22 | 0.00 | 0.00 |
| core_arrow | baseline | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 22.53 | 0.00 | 0.00 |
| core_arrow | guided | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 77.6% | 18.15 | 1.38 | 1.06 |
| core_arrow | metamorphic | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 4.72 | 0.00 | 0.00 |
| core_arrow | no_feedback | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 99.8% | 22.57 | 0.00 | 0.00 |
| core_arrow | no_normalizer | 5 | 2500 | 705 | 0 | 0.0% | 0.00 |  | 0 | 705 | 85.8% | 22.79 | 0.00 | 0.00 |
| core_arrow | no_type_aware | 5 | 2500 | 29 | 10 | 0.4% | 0.10 | 25 | 19 | 0 | 82.2% | 25.13 | 0.00 | 0.00 |
| core_datafusion | baseline | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 474 | 0 | 0 | 82.8% | 20.35 | 0.00 | 0.00 |
| core_datafusion | guided | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 434 | 0 | 0 | 77.5% | 16.01 | 1.38 | 1.06 |
| core_datafusion | metamorphic | 5 | 2500 | 1 | 1 | 0.0% | 0.00 | 474 | 0 | 0 | 82.8% | 4.19 | 0.00 | 0.00 |
| core_datafusion | no_feedback | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 474 | 0 | 0 | 99.8% | 20.34 | 0.00 | 0.00 |
| core_datafusion | no_normalizer | 5 | 2500 | 708 | 0 | 0.0% | 0.00 |  | 0 | 707 | 86.1% | 20.44 | 0.00 | 0.00 |
| core_datafusion | no_type_aware | 5 | 2500 | 40 | 11 | 0.4% | 0.10 | 25 | 29 | 0 | 82.2% | 22.79 | 0.00 | 0.00 |
| core_lazy | baseline | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 24.01 | 0.00 | 0.00 |
| core_lazy | guided | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 77.6% | 18.91 | 1.38 | 1.06 |
| core_lazy | metamorphic | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 82.8% | 4.97 | 0.00 | 0.00 |
| core_lazy | no_feedback | 5 | 2500 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 99.8% | 23.82 | 0.00 | 0.00 |
| core_lazy | no_normalizer | 5 | 2500 | 705 | 0 | 0.0% | 0.00 |  | 0 | 705 | 86.2% | 23.95 | 0.00 | 0.00 |
| core_lazy | no_type_aware | 5 | 2500 | 29 | 10 | 0.4% | 0.11 | 25 | 19 | 0 | 82.2% | 26.36 | 0.00 | 0.00 |
| datafusion_cross | baseline | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 474 | 0 | 0 | 82.8% | 24.25 | 0.00 | 0.00 |
| datafusion_cross | guided | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 434 | 0 | 0 | 77.5% | 18.46 | 1.38 | 1.06 |
| datafusion_cross | metamorphic | 5 | 2500 | 1 | 1 | 0.0% | 0.00 | 474 | 0 | 0 | 82.8% | 4.98 | 0.00 | 0.00 |
| datafusion_cross | no_feedback | 5 | 2500 | 1 | 1 | 0.0% | 0.01 | 474 | 0 | 0 | 99.8% | 24.39 | 0.00 | 0.00 |
| datafusion_cross | no_normalizer | 5 | 2500 | 701 | 1 | 0.0% | 0.01 | 481 | 0 | 699 | 86.3% | 24.25 | 0.00 | 0.00 |
| datafusion_cross | no_type_aware | 5 | 2500 | 37 | 8 | 0.3% | 0.09 | 93 | 29 | 0 | 82.2% | 27.11 | 0.00 | 0.00 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| arrow_cross | baseline | 0 | none |
| arrow_cross | guided | 0 | none |
| arrow_cross | metamorphic | 0 | none |
| arrow_cross | no_feedback | 0 | none |
| arrow_cross | no_normalizer | 0 | none |
| arrow_cross | no_type_aware | 2 | groupby_aggregation@duckdb:4; arithmetic_expression@duckdb:1 |
| core | baseline | 0 | none |
| core | guided | 0 | none |
| core | metamorphic | 0 | none |
| core | no_feedback | 0 | none |
| core | no_normalizer | 0 | none |
| core | no_type_aware | 3 | arithmetic_expression@sqlite:4; groupby_aggregation@duckdb,sqlite:3; arithmetic_expression@duckdb,pandas,polars,sqlite:1 |
| core_arrow | baseline | 0 | none |
| core_arrow | guided | 0 | none |
| core_arrow | metamorphic | 0 | none |
| core_arrow | no_feedback | 0 | none |
| core_arrow | no_normalizer | 0 | none |
| core_arrow | no_type_aware | 5 | arithmetic_expression@sqlite:4; groupby_aggregation@duckdb,polars_lazy,sqlite:3; groupby_aggregation@duckdb:1; arithmetic_expression@duckdb,sqlite:1; groupby_aggregation@polars_lazy:1 |
| core_datafusion | baseline | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | guided | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | metamorphic | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | no_feedback | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | no_normalizer | 0 | none |
| core_datafusion | no_type_aware | 8 | arithmetic_expression@sqlite:3; groupby_aggregation@datafusion,duckdb,polars_lazy,sqlite:2; groupby_aggregation@duckdb:1; groupby_aggregation@datafusion,duckdb,sqlite:1; grouped_topk_null_sort_key@datafusion:1 |
| core_lazy | baseline | 0 | none |
| core_lazy | guided | 0 | none |
| core_lazy | metamorphic | 0 | none |
| core_lazy | no_feedback | 0 | none |
| core_lazy | no_normalizer | 0 | none |
| core_lazy | no_type_aware | 4 | arithmetic_expression@sqlite:4; groupby_aggregation@duckdb,polars_lazy,sqlite:3; groupby_aggregation@polars_lazy:2; arithmetic_expression@duckdb,sqlite:1 |
| datafusion_cross | baseline | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | guided | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | metamorphic | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | no_feedback | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | no_normalizer | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | no_type_aware | 6 | groupby_aggregation@datafusion,duckdb,pandas:3; groupby_aggregation@duckdb:1; grouped_topk_null_sort_key@datafusion:1; arithmetic_expression@datafusion:1; arithmetic_expression@pandas:1 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
