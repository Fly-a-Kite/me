# DataDiffFuzz Experiment Analysis

- Manifest: `runs/experiment-20260514T175130.json`
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T175130-aggregates.csv`
- Baseline preset: `baseline`

## Soundness Snapshot

Non-seeded target suites executed 60000 cases with 13503 findings, 13503 candidate implementation bugs, and 0 oracle false positives.

## Targeted Guidance Contrasts

| target suite | preset | candidate case % | rate delta | rate ratio | candidate cases/s | yield delta | yield ratio | median first | first delta |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|

## All Baseline Comparisons

| target suite | preset | targeted | candidate case % | rate ratio | candidate cases/s | yield ratio | median first |
|---|---|---|---:|---:|---:|---:|---:|
