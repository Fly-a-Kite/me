# DataDiffFuzz Experiment Analysis

- Manifest: `runs/experiment-20260514T181521.json`
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T181521-aggregates.csv`
- Baseline preset: `baseline`

## Soundness Snapshot

Non-seeded target suites executed 100 cases with 75 findings, 75 candidate implementation bugs, and 0 oracle false positives.

## Targeted Guidance Contrasts

| target suite | preset | candidate case % | rate delta | rate ratio | candidate cases/s | yield delta | yield ratio | median first | first delta |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|

## All Baseline Comparisons

| target suite | preset | targeted | candidate case % | rate ratio | candidate cases/s | yield ratio | median first |
|---|---|---|---:|---:|---:|---:|---:|
