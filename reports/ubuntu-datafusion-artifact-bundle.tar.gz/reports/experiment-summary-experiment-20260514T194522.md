# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T194522.json`
- Runs: 12
- Presets: null_groupby_topk, null_agg_topk
- Seeds: 12001, 13001, 14001
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, sqlite
- Target suite: core_datafusion,datafusion_cross
- Target suites: core_datafusion, datafusion_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T194522-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core_datafusion | null_groupby_topk | 12001 | 300 | 210 | 210 | 70.0% | 0 | 0 | 0 | 16.7% | 25.40 | 1.13 | 0.90 | 0.61 | 4.46 | 0.0% | grouped_topk_null_sort_key:210 | candidate_implementation_bug:210 |
| core_datafusion | null_groupby_topk | 13001 | 300 | 213 | 213 | 71.0% | 1 | 0 | 0 | 18.0% | 25.28 | 1.14 | 0.90 | 0.61 | 4.47 | 0.0% | grouped_topk_null_sort_key:213 | candidate_implementation_bug:213 |
| core_datafusion | null_groupby_topk | 14001 | 300 | 233 | 233 | 77.7% | 0 | 0 | 0 | 18.7% | 25.49 | 1.14 | 0.90 | 0.61 | 4.47 | 0.0% | grouped_topk_null_sort_key:233 | candidate_implementation_bug:233 |
| core_datafusion | null_agg_topk | 12001 | 300 | 144 | 144 | 48.0% | 0 | 0 | 0 | 50.7% | 26.36 | 0.99 | 0.77 | 0.61 | 4.69 | 0.0% | grouped_topk_null_sort_key:144 | candidate_implementation_bug:144 |
| core_datafusion | null_agg_topk | 13001 | 300 | 159 | 159 | 53.0% | 0 | 0 | 0 | 49.7% | 25.78 | 1.00 | 0.77 | 0.61 | 4.70 | 0.0% | grouped_topk_null_sort_key:159 | candidate_implementation_bug:159 |
| core_datafusion | null_agg_topk | 14001 | 300 | 209 | 209 | 69.7% | 0 | 0 | 0 | 41.7% | 26.11 | 1.02 | 0.76 | 0.61 | 4.70 | 0.0% | grouped_topk_null_sort_key:209 | candidate_implementation_bug:209 |
| datafusion_cross | null_groupby_topk | 12001 | 300 | 210 | 210 | 70.0% | 0 | 0 | 0 | 16.7% | 28.43 | 1.13 | 0.90 | 0.61 | 4.46 | 0.0% | grouped_topk_null_sort_key:210 | candidate_implementation_bug:210 |
| datafusion_cross | null_groupby_topk | 13001 | 300 | 213 | 213 | 71.0% | 1 | 0 | 0 | 18.0% | 28.51 | 1.14 | 0.90 | 0.61 | 4.47 | 0.0% | grouped_topk_null_sort_key:213 | candidate_implementation_bug:213 |
| datafusion_cross | null_groupby_topk | 14001 | 300 | 233 | 233 | 77.7% | 0 | 0 | 0 | 18.7% | 28.61 | 1.14 | 0.90 | 0.61 | 4.47 | 0.0% | grouped_topk_null_sort_key:233 | candidate_implementation_bug:233 |
| datafusion_cross | null_agg_topk | 12001 | 300 | 144 | 144 | 48.0% | 0 | 0 | 0 | 50.7% | 30.33 | 0.99 | 0.77 | 0.61 | 4.69 | 0.0% | grouped_topk_null_sort_key:144 | candidate_implementation_bug:144 |
| datafusion_cross | null_agg_topk | 13001 | 300 | 159 | 159 | 53.0% | 0 | 0 | 0 | 49.7% | 30.46 | 1.00 | 0.77 | 0.61 | 4.70 | 0.0% | grouped_topk_null_sort_key:159 | candidate_implementation_bug:159 |
| datafusion_cross | null_agg_topk | 14001 | 300 | 209 | 209 | 69.7% | 0 | 0 | 0 | 41.7% | 30.24 | 1.02 | 0.76 | 0.61 | 4.70 | 0.0% | grouped_topk_null_sort_key:209 | candidate_implementation_bug:209 |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| core_datafusion | null_agg_topk | 3 | 900 | 512 | 512 | 56.9% | 14.84 | 0 | 0 | 0 | 47.3% | 26.08 | 1.00 | 0.77 |
| core_datafusion | null_groupby_topk | 3 | 900 | 656 | 656 | 72.9% | 18.51 | 0 | 0 | 0 | 17.8% | 25.39 | 1.14 | 0.90 |
| datafusion_cross | null_agg_topk | 3 | 900 | 512 | 512 | 56.9% | 17.26 | 0 | 0 | 0 | 47.3% | 30.34 | 1.00 | 0.77 |
| datafusion_cross | null_groupby_topk | 3 | 900 | 656 | 656 | 72.9% | 20.79 | 0 | 0 | 0 | 17.8% | 28.52 | 1.14 | 0.90 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| core_datafusion | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:512 |
| core_datafusion | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:656 |
| datafusion_cross | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:512 |
| datafusion_cross | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:656 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
